package in.vikas.dto;

public class EmpDTO {

	private Integer empId;
	private String empName;
	private String empEmail;
	private String empGender;
	private String empDept;
	private Integer empExp;
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	public String getEmpDept() {
		return empDept;
	}
	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}
	public Integer getEmpExp() {
		return empExp;
	}
	public void setEmpExp(Integer empExp) {
		this.empExp = empExp;
	}

	
}
